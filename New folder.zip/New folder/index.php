<?php
echo str_repeat('hi', 3);
?>